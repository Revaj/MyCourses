package sistemaDistribuido.sistema.clienteServidor.modoUsuario;


/**
 * 
 * @author Javier Agustin Rizo Orozco
 * @seccion D04
 * @tarea 3
 * 
 * Conversor Bytes
 * Convierte mensajes string a bytes y viceversa e imprime el
 * resultado ya sea en string o el valor ascii de cada caracter
 *
 */
public class CadenaBytes {
	
    private String cadena;
    private byte[] arregloBytes = new byte[128];
	
	public CadenaBytes(String cadena) {
		this.cadena = cadena;
	}
	

	public CadenaBytes(){
		this.cadena = " ";
	}
	
	public byte[] dameArregloBytes() {
		int longitud = this.cadena.length();
		arregloBytes[0] = (byte) longitud;
		byte[] cadenaBytes;

		cadenaBytes = this.cadena.getBytes();
		for(int i = 1; i < (longitud + 1); i++) {
			arregloBytes[i] = cadenaBytes[i - 1];
		}
		
		return arregloBytes;
	}
	
	public byte[] dameArregloBytes(String cadena) {
			int longitud = cadena.length();
			//Tamanio de la cadena mas uno para guardar el tamanio
			byte[] arregloBytes = new byte[longitud + 1];
			arregloBytes[0] = (byte) longitud;
			byte[] cadenaBytes = cadena.getBytes();
			for(int i = 1; i < (longitud + 1); i++) {
				arregloBytes[i] = cadenaBytes[i - 1];
			}
			
			return arregloBytes;
	}
	
	public void imprimeArregloNumerico(byte[] arreglo){
		int longitud = arreglo[0];
		for(int i = 1; i < longitud + 1; i++) {
			System.out.println(arreglo[i]);
		}
	}
	
	public void imprimeArregloCadena(byte[] arreglo){
		int longitud = arreglo[0];
		for(int i = 1; i < longitud + 1;i++) {
			System.out.print((char) arreglo[i]);
		}
	}
	
	public String recuperaCadena(byte[] arreglo){
		String mensaje = "";
		int longitud = arreglo[0];
		for(int i = 1; i < longitud + 1;i++) {
			mensaje += (char) arreglo[i];
		}

		
		return mensaje;
	}
	
    public byte[] convierteByte(short nvoValor){
    	byte [] arreglo =	new byte[2];
    	arreglo[0] = (byte) (nvoValor) ;
	    arreglo[1] = (byte) (nvoValor >> 8);
	    return arreglo;
	}

    
    public short recuperaBytesShort(byte[] arreglo){
    	short shot = -1;
    	if(arreglo.length > 0){
    		shot = 
    				(short) (((arreglo[1] & 0xff) << 8) | (arreglo[0] & 0xff));		  
		}
    	return  shot;
	}
}

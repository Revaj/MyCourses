package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.StringTokenizer;
import java.util.Vector;




import sistemaDistribuido.sistema.clienteServidor.modoMonitor.MaquinaProceso;
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.ParMaquinaProceso;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;
import sistemaDistribuido.util.Pausador;

/**
 * Javier Agustin Rizo Orozco
 * Practica 5
 * 208091714
 */
public class ProcesoServidor extends Proceso{

	/**
	 * 
	 */
	
	//Constantes a usar para tamanios
	private final int TAMANIO_BYTES_ID_EMISOR = 4;
	private final int TAMANIO_BYTES_ID_RECEPTOR = 4;
	private final int TAMANIO_BYTES_CODIGO_OPERACION = 2;
	private final int TAMANIO_BYTES_MENSAJE = 1016;
	private final int TAMANIO_BYTES_RESPUESTA = 1024;
	private final int CASO_CREAR = 0;
	private final int CASO_ELIMINAR = 1;
	private final int CASO_LEER = 2;
	private final int CASO_ESCRIBIR = 3;
	private boolean lineaEncontrada;

	
	public ProcesoServidor(Escribano esc){
		super(esc);
		start();
		lineaEncontrada = false;
	}
	
	public boolean creaArchivo(String archivoFuente, String mensajeFuente){
		boolean exito = true;
		try {
			BufferedWriter escritor = new BufferedWriter(new FileWriter(archivoFuente));
			//Cliente desea escribir mensaje
			if (mensajeFuente.length() > 0) {
				escritor.write(mensajeFuente);
			}
			escritor.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			exito = false;
			e.printStackTrace();
		}
		return exito;
	}
	
	//La diferencia es que el primer metodo crea (o sobreescribe) un archivo fuente y si el 
	//cliente deseo incluir un mensaje, se realiza. Este metodo verifica que el archivo fuente exista
	//si existe el mensaje se escribe al final de la linea y dependiendo de la posicion se hace una
	//interseccion entre lineas para escribir la linea del mensaje
	
	/**
	 * 
	 * @param archivoFuente
	 * @param mensaje
	 * @param numeroLinea
	 * @return exito
	 * 
	 * Para este metodo vamos a trabajar con 2 archivos, uno de lectura temporal y otro de escritura que sera el nuevo
	 * Se que es un poco tedioso usar dos archivos a la vez, pero si tomamos en cuenta que de los tres casos, dos de ellos
	 * requieren que mueva el contenido de las lineas entonces es mas viable, al menos que nos metamos a nivel bajo y queramos
	 * tener pesadillas horribles con el sistema de archivos.
	 */
	public boolean escribeArchivo(String archivoFuente, String mensaje, int numeroLinea){
		boolean exito = true;
		int lineaActual = 0;
		String lineaCadena = "";
		try {
			BufferedWriter escritor = new BufferedWriter(new FileWriter("tmp.txt"));
			BufferedReader lector = new BufferedReader(new FileReader(archivoFuente));
			//Cliente desea escribir mensaje
			while((lineaCadena = lector.readLine()) != null){
				if(lineaActual == numeroLinea){
					escritor.newLine();//Anadimos tambien una linea nueva
					escritor.write(mensaje);//Anadimos el mensaje en la posicion deseada
				}
				escritor.newLine();
				escritor.write(lineaCadena);
				lineaActual++;
			}
			
			//Resulto que la linea era al final del archivo, simplemente lo anadimos y listo
			//Ya que el recorrido de lineas va de 0 - N en numeros naturales.
			if(numeroLinea == -1){
				escritor.newLine();
				escritor.write(mensaje);
			}
			
			
			escritor.close();
			lector.close();
			
			//Eliminamos archivo viejo y renombramos el nuevo
			File archivoViejo = new File(archivoFuente);
			File archivoNuevo = new File("tmp.txt");
			
			if(archivoViejo.delete()){
				archivoNuevo.renameTo(archivoViejo);//Renombramos el viejo con el nuevo
			}else{
				exito = false; //El Servidor tuvo problemas a la hora de hacer el cambio por razones "desconocidas".
							   //Por lo tanto "perdimos" tiempo y no escribimos en el archivo
							   // al final de cuentas porque lo unico que hicimos es hacer un archivo nuevo, es por eso que mandamos error
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			exito = false;
			e.printStackTrace();
		}
		return exito;
	}
	
	public boolean eliminaArchivo(String archivoFuente) {
		return new File(archivoFuente).delete();
	}
	
	
	/**
	 * 
	 * @param archivoFuente
	 * @param listaLineas
	 * @param rango
	 * @return el mensaje obtenido
	 * 
	 * Para este metodo "simplemente" leemos un archivo
	 * Si tenemos una linea indicada leemos la linea
	 * Si tenemos dos lineas indicadas y el booleano de rango activo generamos una lista de lineas
	 * Caso contrario si tenemos dos o mas lineas indicadas con el rango desactivado tenemos de nuevo
	 * una lista de lineas. El chiste es que con la lista de lineas la reordenamos para ver que lineas del archivo
	 * extraer.
	 */
	public String lecturaArchivos(String archivoFuente, Vector<Integer> listaLineas, boolean rango){
		String mensaje = null;
		int numLinea = 0;
		if(listaLineas == null){//Simplemente leemos el archivo
			try {
				BufferedReader lector = new BufferedReader(new FileReader(archivoFuente));
				//Cliente desea escribir mensaje
				String linea = null;
				mensaje = "";
				while((linea = lector.readLine()) != null){
					mensaje += linea;
				}
				lector.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				mensaje = null;
				e.printStackTrace();
			}
			
			return mensaje;
		} else if(rango){//Rango activado
			Collections.sort(listaLineas);
			//Creamos el rango de lineas
			for(int i = listaLineas.firstElement() + 1, j = listaLineas.lastElement(); i < j; i++){
				listaLineas.add(i);
			}	
		}
		
		Collections.sort(listaLineas);//Vuelve a reordenar la lista
		
		//Empezamos a leer el archivo
		try {
			BufferedReader lector = new BufferedReader(new FileReader(archivoFuente));
			//Cliente desea escribir mensaje
			String linea = null;
			mensaje = "";
			while((linea = lector.readLine()) != null && listaLineas.size() != 0){
				if(listaLineas.firstElement() == numLinea) {
					mensaje += numLinea + ":"+ linea + "\n";
					listaLineas.remove(0);
					lineaEncontrada = true;
				}
				numLinea++;
			}
			lector.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			mensaje = null;
			e.printStackTrace();
		}
		return mensaje;
		
	}

	/**
	 * Formato de solicitud de Envio
	 * Posicion 8 (leemos un CODOP valido entre 0-3)
	 * CODOP:
	 * 0 - CREAR
	 * 1 - ELIMINAR
	 * 2 - LEER
	 * 3 - ESCRIBIR
	 * 
	 * Formato Mensaje
	 * CASO CREAR
	 * <archivo_fuente> //Crear un archivo unicamente
	 * <archivo_fuente>|;<mensaje> //Aparte de crear un archivo, crea el mensaje.
	 * 
	 * CASO ELIMINAR
	 * <archivo_fuente> //Elimina archivo indicado
	 * 
	 * CASO LEER
	 * <archivo_fuente> //Lee TODO el archivo
	 * <archivo_fuente>|;<numLinea> //Lee la linea indicada del archivo fuente
	 * <archivo_fuente>|;<numLineaInicio>|;<numLineaFin> //Lee un rango de lineas indicado
	 * <archivo_fuente>|;<numLinea>*<numLinea> //Lee mas de una linea indicada
	 * El numero de lineas empieza desde 0-N
	 * archivo.txt|;4*3 
	 * archivo.txt|;3*4 
	 * archivo.txt|;3*4*7*10
	 * archivo.txt|;3*4*10*7
	 * 
	 * Se recomienda que la lista de lineas sea ascendente para que el ordenamiento a usar no necesite 
	 * mas que una sola iteracion. De todas formas no es mucha diferencia para procesadores de media o alta gama
	 * 
	 * 
	 * CASO ESCRIBIR
	 * <archivo_fuente>|;<mensaje> //Escribe el mensaje al final del archivo
	 * <archivo_fuente>|;<mensaje>|;H //Escribe el mensaje como encabezado (al principio), tambien se puede interpretar como
	 * 
	 * <archivo_fuente>|;<mensaje>|;0 Aunque no es necesario anadir un digito para escribirlo en el principio
	 * 
	 * No anadi una opcion para agregarlo al final porque precisamente sino indico una opcion para que posicion de linea deseo anadirlo
	 * se anadira por default al final de la linea (ademas de que seria muy tedioso validar una opcion que indique que deba anadirlo al final de la linea,
	 * asi que para evitar complicaciones mejor por default se anadira al final de la linea y no tendre que generar codigo de mas para hacerlo mas tedioso
	 * el hecho de validarlo.
	 * 
	 * <archivo_fuente>|;<mensaje>|;<numLinea> //Escribe el mensaje en la linea indicada
	 * si la linea indicada ya hay una linea, esta ultima se mueve a la siguiente posicion para dejar libre la nueva
	 * linea en el archivo
	 * 
	 * El numero de lineas empieza desde 0-N
	 */
	public void run(){
		imprimeln("Proceso servidor en ejecucion.");
		imprimeln("Registro a procesos locales");
		ParMaquinaProceso asa = null;
		try {
			asa = (ParMaquinaProceso) new MaquinaProceso(InetAddress.getLocalHost().getHostAddress(), dameID());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			imprimeln("Error al registrarme, quede inutil ahora :( ");
		}
		if(asa != null)
			Nucleo.registraServicio(asa);//Existe otro servicio pero ese es usado en hash table y no debemos perder referencias
		byte[] solServidor=new byte[TAMANIO_BYTES_RESPUESTA];
		short codigoOperacion;
		StringTokenizer separador = null;
		boolean estado;
		byte[] respServidor;
		CadenaBytes conversor = new CadenaBytes();
		String mensaje = null;
		Vector <Integer> listaLineas;
		String contenido;
		String archivoFuente;
		String mensajeArchivo;
		
		while(continuar()){
			Nucleo.receive(dameID(),solServidor);
			int idCliente = (int) solServidor[0];
			imprimeln("Procesando peticion recibida por el cliente " + idCliente);
			
			listaLineas = new Vector<Integer>();
			byte[] codop = new byte[TAMANIO_BYTES_CODIGO_OPERACION];
			codop[0] = solServidor[TAMANIO_BYTES_ID_EMISOR 
			                           + TAMANIO_BYTES_ID_RECEPTOR];
			codop[1] = solServidor[TAMANIO_BYTES_ID_EMISOR 
				                       + TAMANIO_BYTES_ID_RECEPTOR + 1];
			codigoOperacion = conversor.recuperaBytesShort(codop);
			byte [] mensajeBytes = new byte[TAMANIO_BYTES_MENSAJE];
			int longitudMensaje = (int) solServidor[10];
			longitudMensaje += TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR +
							   TAMANIO_BYTES_CODIGO_OPERACION + 1;
			
			for(int i = 10, j = 0; i < longitudMensaje; i++, j++){
				mensajeBytes[j] = solServidor[i];
			}
			
			mensaje = conversor.recuperaCadena(mensajeBytes);
			if(mensaje.length() > 0){
				switch(codigoOperacion){
					case CASO_CREAR:
					imprimeln("El cliente envio solicitud para CREAR UN ARCHIVO");
					separador = new StringTokenizer(mensaje, "|;");
					archivoFuente = separador.nextToken();
					mensajeArchivo = "";
					if(separador.hasMoreTokens()){
						mensajeArchivo = separador.nextToken();
						imprimeln("El cliente me envio contenido para anadir al nuevo archivo");
					}
					imprimeln("Creando archivo de nombre " +archivoFuente);
					estado = this.creaArchivo(archivoFuente, mensajeArchivo);
					if(estado) {
						mensaje = "Archivo Creado con Exito por el Servidor";
					}
					else {
						mensaje = "El Servidor tuvo problemas para poder crear el archivo";
					}
					break;
					
					case CASO_ELIMINAR:				
					imprimeln("El cliente envio solicitud para ELIMINAR UN ARCHIVO");
					imprimeln("Eliminando archivo de nombre" + mensaje);
					estado = this.eliminaArchivo(mensaje);
					if(estado) {
						mensaje = "Archivo Eliminado con Exito";
					}
					else {
						mensaje = "El Servidor tuvo problemas para poder eliminar el archivo";
					}
					break;
					
					case CASO_LEER:
						imprimeln("El cliente envio solicitud para LEER un archivo");
						separador = new StringTokenizer(mensaje, "|;");
						archivoFuente = separador.nextToken();
						mensajeArchivo = "";
						if(separador.countTokens() == 1) {
							//Buscamos en que caso entra, una sola linea, un rango o una lista de lineas
							//Una sola linea
							//Verificamos que realmente sea una sola linea o una lista de lineas
							separador = new StringTokenizer(separador.nextToken(), "*");
							if(separador.countTokens() == 1) {//Solo una linea al fin y al cabo
								listaLineas.add(Integer.parseInt(separador.nextToken()));
								contenido = lecturaArchivos(archivoFuente, listaLineas, false);
								if(contenido != null && lineaEncontrada){
									mensaje = "Contenido del Archivo:\n" + contenido;
									lineaEncontrada = false;
								}
								else {
									mensaje = "El servidor tiene problemas con el archivo a leer\n"
									+ "Archivo No Existe o la linea no existe dentro del archivo";
								}
							} else { //Contiene varias lineas a leer
								while(separador.hasMoreTokens()){
									listaLineas.add(Integer.parseInt(separador.nextToken()));
								}
								
								contenido = lecturaArchivos(archivoFuente, listaLineas, false);
								if(contenido != null){
									mensaje = "Contenido del Archivo:\n" + contenido;
								}
								else {
									mensaje = "El servidor tiene problemas con el archivo a leer\n"
									+ "Archivo No Existe o la lineas inexistentes dentro del archivo";
								}
							}	
						}else if(separador.countTokens() == 2) {//Rango inicio y fin
							listaLineas.add(Integer.parseInt(separador.nextToken()));
							listaLineas.add(Integer.parseInt(separador.nextToken()));
							contenido = lecturaArchivos(archivoFuente, listaLineas, true);
							if(contenido != null){
								mensaje = "Contenido del Archivo:\n" + contenido;
							}
							else {
								mensaje = "El servidor tiene problemas con el archivo a leer\n"
								+ "Archivo No Existe o la linea no existe dentro del archivo";
							}
							
						}else { //Archivo Completo
							contenido = lecturaArchivos(archivoFuente, null, false);
							if(contenido != null){
								mensaje = "Contenido del Archivo:\n" + contenido;
							}
							else {
								mensaje = "El servidor tiene problemas con el archivo a leer\n"
								+ "El archivo esta ocupado o es inexistente";
							}
						}
					break;
					case CASO_ESCRIBIR:
						imprimeln("El cliente envio solicitud para ESCRIBIR UN ARCHIVO");
						separador = new StringTokenizer(mensaje, "|;");
						archivoFuente = separador.nextToken();
						mensajeArchivo = "";
						if(separador.hasMoreTokens()){
							mensajeArchivo = separador.nextToken();
							if(separador.hasMoreTokens()){
								String numeroLinea = separador.nextToken();
								if(numeroLinea.equalsIgnoreCase("H")){//Escribe en la linea 0
									estado = this.escribeArchivo(archivoFuente, mensajeArchivo, 0); //0  = Encabezado
									if(estado) {
										mensaje = "El Servidor logro escribir sobre el archivo";
									}
									else {
										mensaje = "El Servidor tuvo problemas para escribir sobre el archivo";
									}
								}else{//Es entero, convierte y usa el numero de linea
									int numeroEntero = Integer.parseInt(numeroLinea);
									estado = this.escribeArchivo(archivoFuente, mensajeArchivo, numeroEntero);
									if(estado) {
										mensaje = "El Servidor logro escribir sobre el archivo";
									}
									else {
										mensaje = "El Servidor tuvo problemas para escribir sobre el archivo";
									}
								}
								
							}
							else {//Escribe al final del archivo
								estado = this.escribeArchivo(archivoFuente, mensajeArchivo, -1); //-1 = Final del archivo
								if(estado) {
									mensaje = "El Servidor logro escribir sobre el archivo";
								}
								else {
									mensaje = "El Servidor tuvo problemas para escribir sobre el archivo";
								}
							}
						}
						else{
							imprimeln("El cliente NO me envio el contenido para escribir en el archivo");
							mensaje = "Fallo en Escritura del archivo, falto el mensaje";
						}
					break;
					default:
					imprimeln("Codigo de Operacion Invalido");
					mensaje = "No me has enviadao una operacion valida, si tuviera superpoderes te mandaria a destruir"
							+ "Pero no los tengo asi que te perdono";
					break;
				
				}
				//Prepara mensaje
				respServidor = new byte[TAMANIO_BYTES_RESPUESTA];
				mensajeBytes = new byte[TAMANIO_BYTES_MENSAJE];
				mensajeBytes = conversor.dameArregloBytes(mensaje);
				int limiteRespuesta = mensajeBytes.length + TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR;
				for(int i = 8, j = 0; i < limiteRespuesta; i++, j++) {
					respServidor[i] = mensajeBytes[j];
				}
	
				Pausador.pausa(1000);  //sin esta l�nea es posible que Servidor solicite send antes que Cliente solicite receive
				imprimeln("Enviando respuesta al cliente");
				Nucleo.send(idCliente,respServidor);
		}
		}
		
		Nucleo.deregistraServicio(asa);//Ya no soy necesario y debo morir de la lista :(
	}
	
}

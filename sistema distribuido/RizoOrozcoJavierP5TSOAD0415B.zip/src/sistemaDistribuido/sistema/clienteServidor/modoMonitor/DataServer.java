package sistemaDistribuido.sistema.clienteServidor.modoMonitor;

/**
 * 
 * Javier Rizo Orozco
 * Practica 5
 * 208091714
 * 
 * Este dataserver difiere del otro dataserver con respecto al numero del servicio
 *
 */
public class DataServer {
	private int numeroServicio;
	private ParMaquinaProceso servidor;
	
	public DataServer(int numeroServicio, ParMaquinaProceso servidor){
		this.numeroServicio = numeroServicio;
		this.servidor = servidor;
	}

	public int getNumeroServicio() {
		return numeroServicio;
	}

	public void setNumeroServicio(int numeroServicio) {
		this.numeroServicio = numeroServicio;
	}

	public ParMaquinaProceso getServidor() {
		return servidor;
	}

	public void setServidor(ParMaquinaProceso servidor) {
		this.servidor = servidor;
	}
}

package sistemaDistribuido.sistema.clienteServidor.modoMonitor;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.StringTokenizer;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.MicroNucleoBase;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.CadenaBytes;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;

/**
 * Javier Rizo Orozco
 * Practica 5
 * 208091714
 */
public final class MicroNucleo extends MicroNucleoBase{
	private static MicroNucleo nucleo=new MicroNucleo();
	Hashtable<Integer,MaquinaProceso> tablaEmisor = new Hashtable<Integer, MaquinaProceso>();
    Hashtable<Integer,byte[]> tablaRecepcion = new Hashtable<Integer, byte[]>();
    
    //Practica 5
    public static LinkedList<Object> tablaProcesosRemotos = new LinkedList<Object>();
    public static LinkedList<Object> tablaProcesosLocales = new LinkedList<Object>();

    //Constantes
    final private int POSICION_ID_EMISOR = 0;
    final private int POSICION_ID_RECEPTOR = 4;
    final private int TAMANIO_BUFFER = 1024;
	private final int TAMANIO_BYTES_ID_EMISOR = 4;
	private final int TAMANIO_BYTES_ID_RECEPTOR = 4;
	private final int TAMANIO_BYTES_CODIGO_OPERACION = 2;
	private final int TAMANIO_BYTES_RESPUESTA = 1024;
	private final int INICIO_MENSAJE_RESPUESTA = 10;

	/**
	 * 
	 */
	private MicroNucleo(){
	}

	/**
	 * 
	 */
	public final static MicroNucleo obtenerMicroNucleo(){
		return nucleo;
	}

	/*---Metodos para probar el paso de mensajes entre los procesos cliente y servidor en ausencia de datagramas.
    Esta es una forma incorrecta de programacion "por uso de variables globales" (en este caso atributos de clase)
    ya que, para empezar, no se usan ambos parametros en los metodos y fallaria si dos procesos invocaran
    simultaneamente a receiveFalso() al reescriir el atributo mensaje---*/
	byte[] mensaje;

	public void sendFalso(int dest,byte[] message){
		System.arraycopy(message,0,mensaje,0,message.length);
		notificarHilos();  //Reanuda la ejecucion del proceso que haya invocado a receiveFalso()
	}

	public void receiveFalso(int addr,byte[] message){
		mensaje=message;
		suspenderProceso();
	}
	/*---------------------------------------------------------*/

	/**
	 * 
	 */
	protected boolean iniciarModulos(){
		return true;
	}

	/**
	 * Busca en la tabla de emisor el destino para obtener el ip y id
	 * Caso contrario desde la interfaz obtenemos estos datos y mandamos
	 * el datagrama
	 */
	protected void sendVerdadero(int destino, byte[] message){
			
		String ip = "";
        int id = 0 ;
        DataServer servidor = null;
        
		imprimeln("Buscando en listas locales el par(maquina, proceso) que corresponde al parametro dest de la llamada a send");
        if(tablaEmisor.containsKey(destino)){
            imprimeln("Se encontro el proceso destino con el ID: " + destino);
            ip = tablaEmisor.get(destino).dameIP();
            id = tablaEmisor.get(destino).dameID();
        }else if(this.existeServicio(destino)){
        	imprimeln("No hay servicio, busco en la tabla de procesos remotos");
        	servidor = dameServidorActivo(destino);
        	ip = servidor.getServidor().dameIP();
        	id = servidor.getServidor().dameID();
        }
        else{//No encontramos un servicio en la tabla de procesos remotos
        	//Procedemos a molestar con mensajes LSA hasta cansarnos 3 * 5 veces y ren
        	//y rendirse para mandar un AU al cliente
        	int intentos = 1;
        	imprimeln("No encuentro el servidor, mando LSA 3 veces max para encontrarlo");
        	while(intentos++ <= 3){
        		mandaLSA(248);
        		
                try{
    				sleep(5000);
    			}catch(InterruptedException e){
    				System.out.println("InterruptedException");
    			}
                
                if(this.existeServicio(destino)){
                	servidor = dameServidorActivo(destino);
                	ip = servidor.getServidor().dameIP();
                	id = servidor.getServidor().dameID();
                	break;
                }
        	}
        	
        	if(intentos > 3){
        		imprimeln("No se pudo encontrar el sevidor, procede reenvio al cliente");
        	}
        }
          
        imprimeln("Completando campos de encabezado del mensaje a ser enviado");
        message[POSICION_ID_EMISOR] = (byte) super.dameIdProceso();
        message[POSICION_ID_RECEPTOR] = (byte) id;
        imprimeln("id es "+id);
        
        try {
            DatagramPacket paquete = new DatagramPacket(message, message.length, InetAddress.getByName("127.0.0.1"), damePuertoRecepcion());
            imprimeln("Enviando mensaje por la red");
            dameSocketEmision().send(paquete);
        } catch (IOException ex) {
        	imprimeln("Error al enviar el mensaje de Micronucleo");
        }
	}

	//Manda empaqueta y construye mensaje LSA
	private void mandaLSA(int numServicio) {
		// TODO Auto-generated method stub
		imprimeln("Empaquetando LSA");
		CadenaBytes conversor = new CadenaBytes();
		String mensaje = Integer.toString(numServicio);
		int tamanioSolicitud = TAMANIO_BYTES_ID_EMISOR 
							   + TAMANIO_BYTES_ID_RECEPTOR
				               + TAMANIO_BYTES_CODIGO_OPERACION
				               + mensaje.length() + 1;
		byte [] mensajeBytes = new byte[tamanioSolicitud];
		byte [] codop = conversor.convierteByte((short) -10); //Codigo de LSA
		
		//Anade el CODOP  a la solicitud
		int inicioCodop = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR;
		for(int i = inicioCodop, j = 0; i < inicioCodop + TAMANIO_BYTES_CODIGO_OPERACION; 
			i++, j++){
			mensajeBytes[i] = codop[j];
		}
		
		byte [] cadenaMsgBytes = conversor.dameArregloBytes(mensaje);
		int inicioMensaje = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 
							TAMANIO_BYTES_CODIGO_OPERACION;
		
		for(int i = inicioMensaje, j = 0; i < tamanioSolicitud; i++, j++){
			mensajeBytes[i] = cadenaMsgBytes[j];
		}
		
		imprimeln("Servicio "+mensajeBytes[10]);
		
        mensajeBytes[POSICION_ID_EMISOR] = (byte) 0;
        mensajeBytes[POSICION_ID_RECEPTOR] = (byte) 0;

        imprimeln("Enviando LSA");
		 try{
			 DatagramPacket paquete = new DatagramPacket(mensajeBytes, mensajeBytes.length, InetAddress.getByName("127.0.0.1"), damePuertoRecepcion());
	         imprimeln("Enviando mensaje por la red");
	         dameSocketEmision().send(paquete);
	     }catch (IOException ex) {
	         imprimeln("Error al enviar el mensaje de Micronucleo");
	     }		
	}

	//Verifica si hay un servidor activo
	private boolean existeServicio(int destino) {
		// TODO Auto-generated method stub
		for(Object servidor : tablaProcesosRemotos){
			if(((DataServer) servidor).getNumeroServicio() == destino){
				return true;
			}
		}
		return false;
	}
	
	//Devuelve un servidor "activo" de la tabla de procesosremotos
	public DataServer dameServidorActivo(int destino){
		DataServer servidor = null;
		LinkedList<Object> servidoresActivos = new LinkedList<Object>();
		
		for(Object elemento : tablaProcesosRemotos){
			if(((DataServer) elemento).getNumeroServicio() == destino){
				servidoresActivos.add(elemento);
			}
		}
		
		servidor = eligeRandomServidor(servidoresActivos);
		
		return servidor;
	}
	
	
	/**
	 * Transmision RALA, todos los servidores que den el servicio deberan responder
	 * @param destino
	 * @return
	 */
	public LinkedList<Object> dameServidorLocal(int destino){
		LinkedList<Object> servidoresActivos = new LinkedList<Object>();
		
		for(Object elemento : tablaProcesosLocales){
			if(((DataServer) elemento).getNumeroServicio() == destino){
				servidoresActivos.add(elemento);
			}
		}
				
		return servidoresActivos;
	}
	
	//Para cada servidor encontrado, mandamos un fsa para registrarlo
	private void mandaFSA(String mensaje){
		LinkedList<Object> lista = dameServidorLocal(Integer.parseInt(mensaje));
		for(Object elemento : lista){
			if(((DataServer) elemento).getNumeroServicio() == Integer.parseInt(mensaje)){
				imprimeln("Mando mensaje FSA");
				construyeMensajeFSA(mensaje+"|"+
			    ((DataServer) elemento).getServidor().dameID()+"|"+
			    ((DataServer) elemento).getServidor().dameIP());
			}
		}
	}
	
	//De entre nuestros servidores activos escogemos uno al azar
	private DataServer eligeRandomServidor(LinkedList<Object> servidoresActivos) {
		// TODO Auto-generated method stub
		DataServer servidor = null;
		if(servidoresActivos.size() > 0){
			int posicionSeleccion = 1;
			int selecciono = (int)(Math.random() * servidoresActivos.size() + 1);
			for(Object elemento : servidoresActivos){
				if(posicionSeleccion++ == selecciono){
					servidor = (DataServer) elemento;
					break;
				}
			}
		}
		return servidor;
	}

	/**
	 * Registra los procesos que tuvieron exito
	 */
	protected void receiveVerdadero(int addr,byte[] message){
		imprimeln("Recibido mensaje que contiene la ubicacion MaquinaProceso del servidor");
        tablaRecepcion.put(addr, message);
		suspenderProceso();
	}

	/**
	 * Para el(la) encargad@ de direccionamiento por servidor de nombres en pr�ctica 5  
	 */
	protected void sendVerdadero(String dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void sendNBVerdadero(int dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void receiveNBVerdadero(int addr,byte[] message){
	}
	
	
	//Construye, empaqueta y envia mensaje FSA
	public void construyeMensajeFSA(String mensaje){
		CadenaBytes conversor = new CadenaBytes();
		imprimeln("Empaqueto FSA");
		int tamanioSolicitud = TAMANIO_BYTES_ID_EMISOR 
							   + TAMANIO_BYTES_ID_RECEPTOR
				               + TAMANIO_BYTES_CODIGO_OPERACION
				               + mensaje.length() + 1;
		byte [] mensajeBytes = new byte[tamanioSolicitud];
		mensajeBytes[8] = (byte)-20; //Codigo de LSA
		byte [] cadenaMsgBytes = conversor.dameArregloBytes(mensaje);
		int inicioMensaje = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 
							TAMANIO_BYTES_CODIGO_OPERACION;
		
		for(int i = inicioMensaje, j = 0; i < tamanioSolicitud; i++, j++){
			mensajeBytes[i] = cadenaMsgBytes[j];
		}
		
        mensajeBytes[POSICION_ID_EMISOR] = (byte) 0;
        mensajeBytes[POSICION_ID_RECEPTOR] = (byte) 0;
        imprimeln("Mande un FSA");
		 try{
			 DatagramPacket paquete = new DatagramPacket(mensajeBytes, mensajeBytes.length, InetAddress.getByName("127.0.0.1"), damePuertoRecepcion());
	         imprimeln("Enviando mensaje por la red");
	         dameSocketEmision().send(paquete);
	     }catch (IOException ex) {
	         imprimeln("Error al enviar el mensaje de Micronucleo");
	     }		
	}
	
	//Agregamos el servidor Remoto a la lista de procesos remotos
	public void agregaServidorRemoto(int servicio, int id, String ip){
		MaquinaProceso asa = new MaquinaProceso(ip, id);
		ParMaquinaProceso par = asa;
		DataServer servidor = new DataServer(servicio, par);
		imprimeln("Agregando servidor de numServicio: " +servicio+
				  "\nID  "+id);
		tablaProcesosRemotos.add(servidor);
	}
	
	//Elimina el servicio
	public void eliminaServidorRemoto(int id){
		imprimeln("Servidor a eliminar" +id);
		for(Object elemento : tablaProcesosRemotos){
			if(((DataServer) elemento).getServidor().dameID() == id){
				tablaProcesosRemotos.remove(elemento);
			}
		}
	}
	
	//Devuelve el numero de servicio por el id
	public int  dameNumServicioRemoto(int id){
		int numServicio = 0;
		imprimeln("Servidor a encontrar" +id);
		for(Object elemento : tablaProcesosRemotos){
			if(((DataServer) elemento).getServidor().dameID() == id){
				numServicio = ((DataServer) elemento).getNumeroServicio();
				break;
			}
		}
		
		return numServicio;
	}

	/**
	 * 
	 */
	public void run(){
		byte[] buffer = new byte[TAMANIO_BUFFER];
		DatagramPacket dp = new DatagramPacket(buffer, TAMANIO_BUFFER);
		CadenaBytes conversor = new CadenaBytes();

		while(seguirEsperandoDatagramas()){
			try {
		        imprimeln("Recibiendo mensaje de la red");
		        dameSocketRecepcion().receive(dp);
		        int origen = (int) buffer[0];
		        int destino = (int) buffer[4];
		        int codop = (int) buffer[8]; //Verificamos el codop
		        imprimeln("Codop es "+codop);
		        
		        if(codop == -10){//Mando un LSA
		        	//Verifica Servicio este disponible
		        	imprimeln("Recibi un LSA");
		        	
		        	int limiteRespuesta =  buffer[INICIO_MENSAJE_RESPUESTA];
		    		byte[] msjRespuestaBytes = new byte[TAMANIO_BYTES_RESPUESTA];
		    		String mensaje = "";
					limiteRespuesta += TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR +2 + 1;
					for(int i = INICIO_MENSAJE_RESPUESTA, j = 0; i < limiteRespuesta; i++, j++){
						msjRespuestaBytes[j] = buffer[i]; 
					}
					mensaje = conversor.recuperaCadena(msjRespuestaBytes);
					imprimeln(mensaje);
					mandaFSA(mensaje);
		        	
		        } else if(codop == -20){//Mando un FSA, registro el servidor
		        	imprimeln("Recibo FSA");
		        	int limiteRespuesta =  buffer[INICIO_MENSAJE_RESPUESTA];
		    		byte[] msjRespuestaBytes = new byte[TAMANIO_BYTES_RESPUESTA];
		    		String mensaje = "";
					limiteRespuesta += TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 2 +1;
					for(int i = INICIO_MENSAJE_RESPUESTA, j = 0; i < limiteRespuesta; i++, j++){
						msjRespuestaBytes[j] = buffer[i]; 
					}
					mensaje = conversor.recuperaCadena(msjRespuestaBytes);
					StringTokenizer separador = new StringTokenizer(mensaje,"|");
					int servicio, id;
					servicio = Integer.parseInt(separador.nextToken());
					id = Integer.parseInt(separador.nextToken());
					agregaServidorRemoto(servicio, id, separador.nextToken());
		        	
		        }else{
		        	String ip = dp.getAddress().getHostAddress();
			        Proceso proc = dameProcesoLocal(destino);
			        if(proc != null) {
			        	imprimeln("Buscando proceso correspondiente al campo dest del mensaje recibido");
				        if(tablaRecepcion.containsKey(destino)) {
				        	System.arraycopy(buffer, 0, tablaRecepcion.get(destino), 0, buffer.length);
				            tablaEmisor.put(origen, new MaquinaProceso(ip, origen));
				            tablaRecepcion.remove(destino);
				            reanudarProceso(proc);
				        } 
			        } else { //Direccion desconocida, mandamos un mensaje al nucleo del cliente
	                 	imprimeln("AU - Direccion desconocida, reenvio al cliente");
	                 	imprimeln("Borramos servidor del servicio remoto");
	                 	int numeroServicio = dameNumServicioRemoto(destino);
	                 	eliminaServidorRemoto(destino);
	                 	imprimeln("Buscando si hay del mismo servicio para atender");
	                 	boolean hayServicio = existeServicio(numeroServicio);
	                 	if(hayServicio){
	                 		imprimeln("Todavia hay un compa que pueda atender");
	                 		DataServer servidor = dameServidorActivo(numeroServicio);
	                    	ip = servidor.getServidor().dameIP();
	                    	destino = servidor.getServidor().dameID();
	                    	buffer[4] = (byte) destino;
	                 	}else{
	                 		imprimeln("Empaquetando datos del AU");
		                 	buffer[4] = (byte) origen;//Usamos de base el origen para actuar de receptor
		                 	buffer[8] = (byte)-1; //Mandamos un -1 para que detecte el error
		                 	tablaEmisor.put(origen, new MaquinaProceso(ip, origen));
	                 	}
	                 	dp = new DatagramPacket(buffer,buffer.length,InetAddress.getByName("127.0.0.1"),damePuertoRecepcion());
	                 	dameSocketEmision().send(dp);
	                 	if(!hayServicio)
	                 		imprimeln("Paquete AU enviado");
					}
		        }
		    } catch (IOException ex) {
		    	imprimeln("Error grave en el sistema: \n" +ex);
		    }
			
            try{
				sleep(1000);
			}catch(InterruptedException e){
				System.out.println("InterruptedException");
			}
		}
	}

	//Lo agregamos a la tabla emisor para localizarlo
	public void registra(ParMaquinaProceso asa) {
		// TODO Auto-generated method stub
		tablaEmisor.put(asa.dameID(), (MaquinaProceso) asa);
	}

	
	/**
	 * 
	 * Siguientes metodos validos para el servicio, los anteriores son
	 * un ocultamiento u Transparencia al ser RPC
	 */
	//Registra el servicio encontrado
	public void registraServicio(ParMaquinaProceso asa) {
		// TODO Auto-generated method stub
		imprimeln("Registrando Servidor de servicio 248" 
				+ "\nIP " +asa.dameIP()
				+ "\nID " +asa.dameID());
		tablaProcesosLocales.add(new DataServer(248, asa));
		
	}

	//Deregistra el servicio encontrado
	public void deregistraServicio(ParMaquinaProceso asa) {
		// TODO Auto-generated method stub
		for(Object servidor : tablaProcesosLocales){
			if(((DataServer)servidor).getServidor().dameID() == asa.dameID() &&
			   ((DataServer)servidor).getServidor().dameIP().equals(asa.dameIP())){
				imprimeln("Eliminando Servicio de numero " + ((DataServer)servidor).getNumeroServicio() +
						  "\nIP " + ((DataServer)servidor).getServidor().dameIP() +
						  "\nID " + ((DataServer)servidor).getServidor().dameID() );
				tablaProcesosLocales.remove(servidor);
				break;
			}
		}
	}
}

package sistemaDistribuido.sistema.rpc.modoMonitor;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;   //para pr�ctica 4
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.ParMaquinaProceso;
import sistemaDistribuido.sistema.rpc.modoUsuario.ProgramaConector;

/**
 * 
 * Javier Rizo Orozco
 * Practica 4
 * 208091714
 *
 */

public class RPC{
	private static ProgramaConector conector;

	/**
	 * 
	 */
	public static void asignarConector(ProgramaConector con){
		conector=con;
		conector.inicializar();
	}

	/**
	 * Efectua la llamada de busqueda en el conector.
	 * Regresa un dest para la llamada a send(dest,message).
	 */
	public static int importarInterfaz(String nombreServidor,String version){
		ParMaquinaProceso asa = conector.busqueda(nombreServidor, version);
		int dest = -1;
		if(asa != null){
			Nucleo.registraParMaquinaProceso(asa);
			dest = asa.dameID();
		}
		return dest;
	}

	/**
	 * Efectua la llamada a registro en el conector.
	 * Regresa una identificacionUnica para el deregistro.
	 */
	public static int exportarInterfaz(String nombreServidor,String version,ParMaquinaProceso asa){
		int id = conector.registro(nombreServidor,version,asa);
		return id;
	}

	/**
	 * Efectua la llamada a deregistro en el conector.
	 * Regresa el status del deregistro, true significa llevado a cabo.
	 */
	public static boolean deregistrarInterfaz(String nombreServidor,String version,int identificacionUnica){
		boolean status = conector.deregisto(nombreServidor, version, identificacionUnica);
		Nucleo.imprimeln("Estado = " + status);
		return status;
	}
}
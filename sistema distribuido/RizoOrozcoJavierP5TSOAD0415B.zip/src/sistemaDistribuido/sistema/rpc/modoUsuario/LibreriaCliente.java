package sistemaDistribuido.sistema.rpc.modoUsuario;

import sistemaDistribuido.sistema.rpc.modoMonitor.RPC;  //para pr�ctica 4
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.CadenaBytes;
import sistemaDistribuido.sistema.rpc.modoUsuario.Libreria;
import sistemaDistribuido.util.Escribano;

/**
 * 
 * Javier Rizo Orozco
 * Practica 4
 * 208091714
 *
 */

public class LibreriaCliente extends Libreria{

	/**
	 * CODOP de Operaciones
	 * 
	 * 0 - SUMA
	 * 1 - RESTA
	 * 2 - MULTIPLICACION
	 * 3 - DIVISION
	 * 4 - PROMEDIO
	 * 5 - MODA
	 * 6 - EXPONENCIAL
	 * 7 - MODULO
	 * 8 - Maximo
	 * 9 - Minimo
	 */
	private int miID;
	public LibreriaCliente(Escribano esc, int miID){
		super(esc);
		this.miID = miID;
	}

	/**
	 * Ejemplo de resguardo del cliente suma
	 * @param asaDest 
	 */
	//Practicamente la unica diferencia entre las operaciones son
	//los codops, por lo que para que no haya codigo inutil realiza el
	//empaquetado esta funcion
	private void preparaMensaje1(int codop, int asaDest){
		int num1 = (int) pilaRPC.pop();
		int num2 = (int) pilaRPC.pop();
		
		byte[] codigoOperacionBytes = new byte[TAMANIO_BYTES_CODIGO_OPERACION];
		byte[] mensajeBytes = new byte[TAMANIO_BYTES_MENSAJE];
		byte[] respuestaCliente = new byte[TAMANIO_BYTES_RESPUESTA];		
		String mensaje = num1 + "," + num2;
		int tamanioMensaje = mensaje.length() + 1;
		CadenaBytes conversor = new CadenaBytes();
		codigoOperacionBytes = conversor.convierteByte((short) codop);	
		mensajeBytes = conversor.dameArregloBytes(mensaje);
		
		int tamanioSolicitud =   TAMANIO_BYTES_ID_EMISOR 
							   + TAMANIO_BYTES_ID_RECEPTOR
							   + TAMANIO_BYTES_CODIGO_OPERACION
				               + tamanioMensaje;
		byte[] solicitudCliente = new byte[tamanioSolicitud];
		int inicioCodop = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR;
		for(int i = inicioCodop, j = 0; i < inicioCodop + TAMANIO_BYTES_CODIGO_OPERACION; 
			i++, j++){
			solicitudCliente[i] = codigoOperacionBytes[j];
		}
		
		//Aniade el mensaje a la solicitud
		int inicioMensaje = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 
							TAMANIO_BYTES_CODIGO_OPERACION;
		
		for(int i = inicioMensaje, j = 0; i < tamanioSolicitud; i++, j++){
			solicitudCliente[i] = mensajeBytes[j];
		}
		
		/*
		 * Prepara el buffer de Mensajes
		 */
		
		
		Nucleo.send(asaDest, solicitudCliente);
		Nucleo.receive(miID, respuestaCliente);
		
		String mensajeRespuesta = null;
		byte[] msjRespuestaBytes = new byte[TAMANIO_BYTES_RESPUESTA];
		//El primer byte es el estado del mensaje, por medio de ese 
		//estado sabre si funciono o no
		if((int) respuestaCliente[INICIO_MENSAJE_RESPUESTA] > 0) {
			int limiteRespuesta = respuestaCliente[INICIO_MENSAJE_RESPUESTA];
			limiteRespuesta += TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 1;
			for(int i = INICIO_MENSAJE_RESPUESTA, j = 0; i < limiteRespuesta; i++, j++){
				msjRespuestaBytes[j] = respuestaCliente[i]; 
			}
			mensajeRespuesta = conversor.recuperaCadena(msjRespuestaBytes);	
		}else {
			//Asignamos un numero de error al mensaje
			mensajeRespuesta = Integer.toString(-1);
		}
		
		pilaRPC.push(Integer.parseInt(mensajeRespuesta));
	}
	
	/**
	 * Para tipo de arreglo
	 * @param codop
	 * @param asaDest 
	 */
	private void preparaMensaje2(int codop, int asaDest){
		byte[] codigoOperacionBytes = new byte[TAMANIO_BYTES_CODIGO_OPERACION];
		byte[] mensajeBytes = new byte[TAMANIO_BYTES_MENSAJE];
		byte[] respuestaCliente = new byte[TAMANIO_BYTES_RESPUESTA];		
		String mensaje = "";
		
		while(pilaRPC.size() > 0){
			mensaje += pilaRPC.pop() + ",";
		}
		mensaje = mensaje.substring(0, mensaje.length() - 1);
		
		int tamanioMensaje = mensaje.length() + 1;
		CadenaBytes conversor = new CadenaBytes();
		codigoOperacionBytes = conversor.convierteByte((short) codop);	
		mensajeBytes = conversor.dameArregloBytes(mensaje);
		
		int tamanioSolicitud =   TAMANIO_BYTES_ID_EMISOR 
				   + TAMANIO_BYTES_ID_RECEPTOR
	               + TAMANIO_BYTES_CODIGO_OPERACION
	               + tamanioMensaje;
		byte[] solicitudCliente = new byte[tamanioSolicitud];
		int inicioCodop = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR;
		for(int i = inicioCodop, j = 0; i < inicioCodop + TAMANIO_BYTES_CODIGO_OPERACION; 
			i++, j++){
			solicitudCliente[i] = codigoOperacionBytes[j];
		}
		
		//Aniade el mensaje a la solicitud
		int inicioMensaje = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 
							TAMANIO_BYTES_CODIGO_OPERACION;
		
		for(int i = inicioMensaje, j = 0; i < tamanioSolicitud; i++, j++){
			solicitudCliente[i] = mensajeBytes[j];
		}
		
		/*
		 * Prepara el buffer de Mensajes
		 */
		
		
		Nucleo.send(asaDest, solicitudCliente);
		Nucleo.receive(miID, respuestaCliente);
		
		String mensajeRespuesta = null;
		byte[] msjRespuestaBytes = new byte[TAMANIO_BYTES_RESPUESTA];
		//El primer byte es el estado del mensaje, por medio de ese 
		//estado sabre si funciono o no
		if((int) respuestaCliente[INICIO_MENSAJE_RESPUESTA] > 0) {
			int limiteRespuesta = respuestaCliente[INICIO_MENSAJE_RESPUESTA];
			limiteRespuesta += TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 1;
			for(int i = INICIO_MENSAJE_RESPUESTA, j = 0; i < limiteRespuesta; i++, j++){
				msjRespuestaBytes[j] = respuestaCliente[i]; 
			}
			mensajeRespuesta = conversor.recuperaCadena(msjRespuestaBytes);	
		}else {
			//Asignamos un numero de error al mensaje
			mensajeRespuesta = Integer.toString(-1);
		}
		pilaRPC.push(Integer.parseInt(mensajeRespuesta));
	}
	
	/*
	 * 
	 * @see sistemaDistribuido.sistema.rpc.modoUsuario.Libreria#suma()
	 * Busca el servidor Math_server para realizar su operacion
	 */
	
	protected void suma(){
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje1(0, asaDest);
		//...

		//...
	}

	@Override
	protected void resta() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje1(1, asaDest);
	}

	@Override
	protected void multiplicacion() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje1(2, asaDest);
	}

	@Override
	protected void division() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje1(3, asaDest);
	}

	@Override
	protected void promedio() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje2(4, asaDest);
		
	}

	@Override
	protected void moda() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje2(5, asaDest);
	}

	@Override
	protected void modulo() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje1(7, asaDest);
		
	}

	@Override
	protected void exponencial() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje1(6, asaDest);
	}

	@Override
	protected void maximo() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje2(8, asaDest);
		
	}

	@Override
	protected void minimo() {
		// TODO Auto-generated method stub
		int asaDest = RPC.importarInterfaz("Math_server", "3.1");
		preparaMensaje2(9, asaDest);		
	}

}
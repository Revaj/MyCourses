package sistemaDistribuido.sistema.rpc.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.ParMaquinaProceso;
import sistemaDistribuido.visual.rpc.DespleganteConexiones;

import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Iterator;

/**
 * 
 * Javier Rizo Orozco
 * Practica 4
 * 208091714
 *
 */

public class ProgramaConector{
	private DespleganteConexiones desplegante;
	private Hashtable<Object, Object> conexiones;   //las llaves que provee DespleganteConexiones
	private Hashtable<Object, Object> disponibles;

	/**
	 * 
	 */
	public ProgramaConector(DespleganteConexiones desplegante){
		this.desplegante=desplegante;
	}

	/**
	 * Inicializar tablas en programa conector
	 */
	public void inicializar(){
		conexiones=new Hashtable<Object, Object>();
		disponibles = new Hashtable<Object, Object>();
	}

	/**
	 * Remueve tuplas visualizadas en la interfaz gr�fica registradas en tabla conexiones
	 */
	private void removerConexiones(){
		Set<Object> s=conexiones.keySet();
		Iterator<Object> i=s.iterator();
		while(i.hasNext()){
			desplegante.removerServidor(((Integer)i.next()).intValue());
			i.remove();
		}
	}

	/**
	 * Al solicitar que se termine el proceso, por si se implementa como tal
	 */
	public void terminar() {
		removerConexiones();
		desplegante.finalizar();
	}

	public int registro(String nombreServidor, String version,ParMaquinaProceso asa) {
		int idUnica = desplegante.agregarServidor(nombreServidor,version, asa.dameIP(), Integer.toString(asa.dameID())); 
		if(idUnica > 0){//El registro fue correcto entonces registramos en la tabla
			DataServer misDatos = new DataServer(nombreServidor, version, asa);
			conexiones.put(new Integer(idUnica), misDatos);//Registra en la tabla
		}
		return idUnica;
	}

	//Localiza el servidor en la tabla, si lo encuentra eliminalo tanto de la interfaz
	//como de la tabla
	public boolean deregisto(String nombreServidor, String version,
			int identificacionUnica) {
		boolean exito = false;
		// TODO Auto-generated method stub
		if(conexiones.containsKey(identificacionUnica)){
			DataServer servidor = (DataServer) conexiones.get(identificacionUnica);
			
			//Valida que sea el servidor que buscamos
			if(servidor.getNombreServidor().equals(nombreServidor) &&
			   servidor.getVersion().equals(version)){
				conexiones.remove(identificacionUnica);
				desplegante.removerServidor(identificacionUnica);
				exito = true;
			}
		}
		return exito;
	}
	
	//Selecciona por random el asa, si la lista es vacia regresa un null
	public ParMaquinaProceso seleccionaAsa(){
		ParMaquinaProceso asa = null;
		if(disponibles.size() > 0){
			int posicionSeleccion = 1;
			int selecciono = (int)(Math.random() * disponibles.size() + 1);
			Set<Entry<Object, Object>> tabla = disponibles.entrySet();
			Iterator<Entry<Object, Object>> iterador = tabla.iterator();
			while(iterador.hasNext() && posicionSeleccion <= selecciono){
				Map.Entry<Object, Object> nvoAsa;
				nvoAsa = iterador.next();
				if(posicionSeleccion++ == selecciono){//Este seleccionamos
					asa = (ParMaquinaProceso) nvoAsa.getValue();
				}
			}
			disponibles = new Hashtable<Object, Object>();
		}
		return asa;
	}

	//Localiza el asa por un iterador, registralo despues de encontrarlo y
	//despues seleccionamos uno al azar. Sino se encontro regresa null
	public ParMaquinaProceso busqueda(String nombreServidor, String version) {
		// TODO Auto-generated method stub
		Set<Entry<Object, Object>> tabla = conexiones.entrySet();
		Iterator<Entry<Object, Object>> iterador = tabla.iterator();
		ParMaquinaProceso asa = null;
		while(iterador.hasNext()) {
			Map.Entry<Object, Object> servidor;
			servidor = iterador.next();
			int idUnico = (int) servidor.getKey();
			DataServer informacion = (DataServer) servidor.getValue();
			if(nombreServidor.equals(informacion.getNombreServidor()) &&
			   version.equals(informacion.getVersion())){
				asa = informacion.getAsa();
				disponibles.put(new Integer(idUnico), asa);
			}
		}
		return seleccionaAsa();
	}
}

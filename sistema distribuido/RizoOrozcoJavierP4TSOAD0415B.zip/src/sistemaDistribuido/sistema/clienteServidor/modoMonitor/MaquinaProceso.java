package sistemaDistribuido.sistema.clienteServidor.modoMonitor;
/**
 * 
 * Javier Rizo Orozco
 * Practica 4
 * 208091714
 *
 */

public class MaquinaProceso implements ParMaquinaProceso {

    private String ip;
    private int id;

    public MaquinaProceso(String ip, int id){
        this.ip = ip;
        this.id = id;
    }
    
    public String dameIP(){
    	return this.ip;
    }
    
    public int dameID(){
    	return this.id;
    }
}
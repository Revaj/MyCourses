package sistemaDistribuido.sistema.clienteServidor.modoMonitor;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.Hashtable;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.MicroNucleoBase;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;

/**
 * Javier Rizo Orozco
 * Practica 4
 * 208091714
 */
public final class MicroNucleo extends MicroNucleoBase{
	private static MicroNucleo nucleo=new MicroNucleo();
	Hashtable<Integer,MaquinaProceso> tablaEmisor = new Hashtable<Integer, MaquinaProceso>();
    Hashtable<Integer,byte[]> tablaRecepcion = new Hashtable<Integer, byte[]>();
    //Constantes
    final private int POSICION_ID_EMISOR = 0;
    final private int POSICION_ID_RECEPTOR = 4;
    final private int TAMANIO_BUFFER = 1024;

	/**
	 * 
	 */
	private MicroNucleo(){
	}

	/**
	 * 
	 */
	public final static MicroNucleo obtenerMicroNucleo(){
		return nucleo;
	}

	/*---Metodos para probar el paso de mensajes entre los procesos cliente y servidor en ausencia de datagramas.
    Esta es una forma incorrecta de programacion "por uso de variables globales" (en este caso atributos de clase)
    ya que, para empezar, no se usan ambos parametros en los metodos y fallaria si dos procesos invocaran
    simultaneamente a receiveFalso() al reescriir el atributo mensaje---*/
	byte[] mensaje;

	public void sendFalso(int dest,byte[] message){
		System.arraycopy(message,0,mensaje,0,message.length);
		notificarHilos();  //Reanuda la ejecucion del proceso que haya invocado a receiveFalso()
	}

	public void receiveFalso(int addr,byte[] message){
		mensaje=message;
		suspenderProceso();
	}
	/*---------------------------------------------------------*/

	/**
	 * 
	 */
	protected boolean iniciarModulos(){
		return true;
	}

	/**
	 * Busca en la tabla de emisor el destino para obtener el ip y id
	 * Caso contrario desde la interfaz obtenemos estos datos y mandamos
	 * el datagrama
	 */
	protected void sendVerdadero(int destino, byte[] message){
			
		String ip;
        int id ;
        
		imprimeln("Buscando en listas locales el par(maquina, proceso) que corresponde al parametro dest de la llamada a send");
        if(tablaEmisor.containsKey(destino)){
            imprimeln("Se encontro el proceso destino con el ID: " + destino);
            ip = tablaEmisor.get(destino).dameIP();
            id = tablaEmisor.get(destino).dameID();
        }else{
            imprimeln("No se encontro el proceso destino con el ID " + destino);
            ParMaquinaProceso pmp = dameDestinatarioDesdeInterfaz();
            ip = pmp.dameIP();
            id = pmp.dameID();
    		imprimeln("Enviando mensaje a IP=" + ip + " ID = " + id);
        }
        imprimeln("Completando campos de encabezado del mensaje a ser enviado");
        message[POSICION_ID_EMISOR] = (byte) super.dameIdProceso();
        message[POSICION_ID_RECEPTOR] = (byte) id;
        
        try {
            DatagramPacket paquete = new DatagramPacket(message, message.length, InetAddress.getByName(ip), damePuertoRecepcion());
            imprimeln("Enviando mensaje por la red");
            dameSocketEmision().send(paquete);
        } catch (IOException ex) {
        	imprimeln("Error al enviar el mensaje de Micronucleo");
        }
	}

	/**
	 * Registra los procesos que tuvieron exito
	 */
	protected void receiveVerdadero(int addr,byte[] message){
		imprimeln("Recibido mensaje que contiene la ubicacion MaquinaProceso del servidor");
        tablaRecepcion.put(addr, message);
		suspenderProceso();
	}

	/**
	 * Para el(la) encargad@ de direccionamiento por servidor de nombres en pr�ctica 5  
	 */
	protected void sendVerdadero(String dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void sendNBVerdadero(int dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void receiveNBVerdadero(int addr,byte[] message){
	}

	/**
	 * 
	 */
	public void run(){
		byte[] buffer = new byte[TAMANIO_BUFFER];
		DatagramPacket dp = new DatagramPacket(buffer, TAMANIO_BUFFER);

		while(seguirEsperandoDatagramas()){
			try {
		        imprimeln("Recibiendo mensaje de la red");
		        dameSocketRecepcion().receive(dp);
		        int origen = (int) buffer[0];
		        int destino = (int) buffer[4];
		        String ip = dp.getAddress().getHostAddress();
		        Proceso proc = dameProcesoLocal(destino);
		        if(proc != null) {
		            imprimeln("Buscando proceso correspondiente al campo dest del mensaje recibido");
		            if(tablaRecepcion.containsKey(destino)) {
		                System.arraycopy(buffer, 0, tablaRecepcion.get(destino), 0, buffer.length);
		                tablaEmisor.put(origen, new MaquinaProceso(ip, origen));
		                tablaRecepcion.remove(destino);
		                reanudarProceso(proc);
		            }
		        } else { //Direccion desconocida, mandamos un mensaje al nucleo del cliente
                 	imprimeln("AU - Direccion desconocida, reenvio al cliente");
                 	imprimeln("Empaquetando datos del AU");
                 	buffer[4] = (byte) origen;//Usamos de base el origen para actuar de receptor
                 	buffer[8] = (byte)-1; //Mandamos un -1 para que detecte el error
                 	tablaEmisor.put(origen, new MaquinaProceso(ip, origen));
                 	dp = new DatagramPacket(buffer,buffer.length,InetAddress.getByName(ip),damePuertoRecepcion());
                 	dameSocketEmision().send(dp);
					imprimeln("Paquete AU enviado");
				}
		    } catch (IOException ex) {
		    	imprimeln("Error grave en el sistema: \n" +ex);
		    }
			
            try{
				sleep(1000);
			}catch(InterruptedException e){
				System.out.println("InterruptedException");
			}
		}
	}

	//Lo agregamos a la tabla emisor para localizarlo
	public void registra(ParMaquinaProceso asa) {
		// TODO Auto-generated method stub
		tablaEmisor.put(asa.dameID(), (MaquinaProceso) asa);
	}
}

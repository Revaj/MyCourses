package sistemaDistribuido.sistema.rpc.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.ParMaquinaProceso;
/**
 * 
 * Javier Rizo Orozco
 * Practica 4
 * 208091714
 *
 */
public class DataServer {
	private String nombreServidor;
	private String version;
	private ParMaquinaProceso asa;

	public DataServer(String nombreServidor, String version,
			ParMaquinaProceso asa) {
		// TODO Auto-generated constructor stub
		this.setNombreServidor(nombreServidor);
		this.setVersion(version);
		this.setAsa(asa);
	}

	public String getNombreServidor() {
		return nombreServidor;
	}

	public void setNombreServidor(String nombreServidor) {
		this.nombreServidor = nombreServidor;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public ParMaquinaProceso getAsa() {
		return asa;
	}

	public void setAsa(ParMaquinaProceso asa) {
		this.asa = asa;
	}
	
	

}

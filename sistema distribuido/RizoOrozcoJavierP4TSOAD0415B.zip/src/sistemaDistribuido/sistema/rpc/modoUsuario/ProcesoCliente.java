package sistemaDistribuido.sistema.rpc.modoUsuario;

import java.util.StringTokenizer;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;

/**
 * 
 * Javier Rizo Orozco
 * Practica 3
 * 208091714
 *
 */

public class ProcesoCliente extends Proceso{
	private Libreria lib;

	//Parametros
	
	//Booleanos, necesito saber que operacion hacer
	private boolean necesitaPromedio = false;
	private boolean necesitaSuma = false;
	private boolean necesitaResta = false;
	private boolean necesitaMult = false;
	private boolean necesitaDiv = false;
	private boolean necesitaExp = false;
	private boolean necesitaModa = false; //LOL
	private boolean necesitaModulo = false;
	private boolean necesitaMinimo = false;
	private boolean necesitaMaximo = false;
	
	private int suma1, suma2;
	private int resta1, resta2;
	private int mul1, mul2;
	private int div1, div2;
	private int base, exp;
	private int mod1, mod2;
	public int [] arregloModa;
	public int [] arregloPromedio;
	public int [] arregloMinimo;
	public int [] arregloMaximo;
	/**
	 * 
	 */
	
	public void reciboPromedio(String cadenaElem){
		necesitaPromedio = true;
		StringTokenizer separador = new StringTokenizer(cadenaElem);
		int numeroElementos = separador.countTokens();
		arregloPromedio = new int[numeroElementos];
		int i = 0;
		while(separador.hasMoreTokens()){
			arregloPromedio[i] = Integer.parseInt(separador.nextToken());
			i++;
		}
	}
	
	public void reciboMaximos(String cadenaElem){
		necesitaMaximo = true;
		StringTokenizer separador = new StringTokenizer(cadenaElem);
		int numeroElementos = separador.countTokens();
		arregloMaximo = new int[numeroElementos];
		int i = 0;
		while(separador.hasMoreTokens()){
			arregloMaximo[i] = Integer.parseInt(separador.nextToken());
			i++;
		}
	}
	
	public void reciboMinimos(String cadenaElem){
		necesitaMinimo = true;
		StringTokenizer separador = new StringTokenizer(cadenaElem);
		int numeroElementos = separador.countTokens();
		arregloMinimo = new int[numeroElementos];
		int i = 0;
		while(separador.hasMoreTokens()){
			arregloMinimo[i] = Integer.parseInt(separador.nextToken());
			i++;
		}
	}
	
	public void reciboSuma(int suma1, int suma2){
		this.suma1 = suma1;
		this.suma2 = suma2;
		necesitaSuma = true;
	}
	
	public void reciboResta(int resta1, int resta2){
		this.resta1 = resta1;
		this.resta2 = resta2;
		necesitaResta = true;
	}
	
	public void reciboMultiplicacion(int mul1, int mul2){
		this.mul1 = mul1;
		this.mul2 = mul2;
		necesitaMult = true;
	}
	
	public void reciboDivision(int div1, int div2){
		this.div1 = div1;
		this.div2 = div2;
		if(div2 != 0) //No nos arriesgamos a hacer try catchs innecesarios
			necesitaDiv = true;
	}
	
	public void reciboExponente(int base, int exp){
		this.base = base;
		this.exp = exp;
		necesitaExp = true;
	}
	
	public void reciboModa(String cadenaElem){
		necesitaModa = true;
		StringTokenizer separador = new StringTokenizer(cadenaElem);
		int numeroElementos = separador.countTokens();
		arregloModa = new int[numeroElementos];
		int i = 0;
		while(separador.hasMoreTokens()){
			arregloModa[i] = Integer.parseInt(separador.nextToken());
			i++;
		}
	}
	
	public void reciboMod(int mod1, int mod2){
		this.mod1 = mod1;
		this.mod2 = mod2;
		necesitaModulo = true;
	}
	
	
	public ProcesoCliente(Escribano esc){
		super(esc);
		//lib=new LibreriaServidor(esc);  //primero debe funcionar con esta para subrutina servidor local
		lib=new LibreriaCliente(esc, dameID());  //luego con esta comentando la anterior, para subrutina servidor remota
		start();
	}


	/**
	 * Programa Cliente
	 * PROMEDIO
	 * ENTRADA
	 * 		  Arreglo Elementos separados por espacio. Elementos son numeros.
	 * 		  Ejemplo
	 *   Entrada>4 5 6 1
	 *   Salida (En Pantalla)
	 *   4
	 * Suma
	 * 		  Elemento 1 y 2. Deben ser enteros
	 *   Entrada1> 2
	 *   Entrada2> 2
	 *   Salida (En Pantalla)
	 *   4
	 * Resta
	 * 		  Mismo caso
	 * 	 Entrada1> 2
	 *   Entrada2> 2
	 *   Salida (En Pantalla)
	 *   0
	 * Multiplicacion
	 * 		  Mismo caso nuevamente
	 * 
	 * 	 Entrada1> 2
	 *   Entrada2> 2
	 *   Salida (En Pantalla)
	 *   4
	 * Division
	 * 		  Mismo caso, segundo numero debe ser != 0 o te rechazo
	 * 	 Entrada1> 2
	 *   Entrada2> 2
	 *   Salida (En Pantalla)
	 *   1
	 * Exponente
	 * 		  Base y Exponente
	 * 	 Entrada1> 2
	 *   Entrada2> 2
	 *   Salida (En Pantalla)
	 *   4
	 * Moda
	 * 		  Otro arreglo de elementos como en promedio
	 * 
	 * 	 Entrada>4 5 6 1 1
	 *   Salida (En Pantalla)
	 *   1
	 * Modulo
	 * 		  Mismo caso de la suma resta, campo1 y 2 con sus respectivos operandos
	 * 	 Entrada1> 2
	 *   Entrada2> 2
	 *   Salida (En Pantalla)
	 *   0
	 * 
	 * Minimo
	 * Entrada
	 * 		Igual como en Promedio y Moda, entras una lista de numeros separados por espacio
	 * 	 Entrada>4 5 6 1 1
	 *   Salida (En Pantalla)
	 *   1
	 * 
	 * Maximo
	 * Entrada
	 * 		Igual como en Promedio, Minimo y Maxi, una lista de numeros separados por espacio
	 * 	 Entrada>4 5 6 1 1
	 *   Salida (En Pantalla)
	 *   6
	 */
	public void run(){
		imprimeln("Proceso cliente en ejecucion.");
		imprimeln("Esperando datos para continuar.");
		Nucleo.suspenderProceso();
		imprimeln("Salio de suspenderProceso");
		
		/**
		 * Lista de acciones
		 * Entra a un menu de opciones donde mandas las acciones por realizar
		 * dependiendo de las banderas activas
		 */

		llamadasRPC();
		imprimeln("Fin del cliente.");
	}
	
	//Por cada bandera activa llamamos a la libreria correspondiente
	public void llamadasRPC(){
		int resultado = -1;
		if(necesitaSuma){
			resultado = lib.suma(suma1, suma2);
			imprimeln("Suma = " + resultado);
		}
		
		if(necesitaResta){
			resultado = lib.resta(resta1, resta2);
			imprimeln("Resta = " + resultado);
		}
		
		if(necesitaMult){
			resultado = lib.multiplicacion(mul1, mul2);
			imprimeln("Multiplicacion = " + resultado);
		}
		
		if(necesitaDiv){
			resultado = lib.division(div1, div2);
			imprimeln("Division = " + resultado);
		}
		
		if(necesitaPromedio){
			resultado = lib.promedio(arregloPromedio);
			imprimeln("Promedio = " + resultado);			
		}
		
		if(necesitaModa){
			resultado = lib.moda(arregloModa);
			imprimeln("Moda = " + resultado);
		}
		
		if(necesitaExp){
			resultado = lib.exponencial(base, exp);
			imprimeln("Exponencial = " + resultado);
		}
		
		if(necesitaModulo){
			resultado = lib.modulo(mod1, mod2);
			imprimeln("Modulo = " + resultado);
		}
		
		if(necesitaMaximo){
			resultado = lib.maximo(arregloMaximo);
			imprimeln("Maximo = " + resultado);
		}
		
		if(necesitaMinimo){
			resultado = lib.minimo(arregloMinimo);
			imprimeln("Minimo = " + resultado);
		}
	}
}

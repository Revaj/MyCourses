package sistemaDistribuido.sistema.rpc.modoUsuario;

import sistemaDistribuido.sistema.rpc.modoUsuario.Libreria;
import sistemaDistribuido.util.Escribano;


/**
 * 
 * Javier Rizo Orozco
 * Practica 3
 * 208091714
 *
 */

public class LibreriaServidor extends Libreria{

	/**
	 * 
	 */
	public LibreriaServidor(Escribano esc){
		super(esc);
	}

	/**
	 * Ejemplo de servidor suma verdadera
	 */
	protected void suma(){
		//saca parametros de pila
		//devuelve valor izquierdo
		int num1, num2;
		int resultado = -1;
		num1 = (int) pilaRPC.pop();
		num2 = (int) pilaRPC.pop();
		resultado = num1 + num2;
		pilaRPC.push(new Integer(resultado));
		
	}

	@Override
	protected void resta() {
		// TODO Auto-generated method stub
		int num1, num2;
		int resultado = -1;
		num1 = (int) pilaRPC.pop();
		num2 = (int) pilaRPC.pop();
		resultado = num1 - num2;
		pilaRPC.push(new Integer(resultado));
		
	}

	@Override
	protected void multiplicacion() {
		// TODO Auto-generated method stub
		int num1, num2;
		int resultado = -1;
		num1 = (int) pilaRPC.pop();
		num2 = (int) pilaRPC.pop();
		resultado = num1 * num2;
		pilaRPC.push(new Integer(resultado));
		
	}

	@Override
	protected void division() {
		// TODO Auto-generated method stub
		int num1, num2;
		int resultado = -1;
		num1 = (int) pilaRPC.pop();
		num2 = (int) pilaRPC.pop();
		resultado = num1 / num2;
		pilaRPC.push(new Integer(resultado));
		
	}

	@Override
	protected void promedio() {
		// TODO Auto-generated method stub
		int arreglo[];
		int sum = 0;
		int resultado = -1;
		arreglo = new int[pilaRPC.size()];
		int i = 0;
		while(!pilaRPC.isEmpty()){
			arreglo[i] = (int) pilaRPC.pop();
			i++;
		}
		
		/*
		 * Calcula Promedio
		 */
		
		for(int j = 0; j < arreglo.length; j++){
			sum += arreglo[j];
		}
		
		resultado = sum / arreglo.length;
		pilaRPC.push(new Integer(resultado));
	}

	@Override
	protected void moda() {
		// TODO Auto-generated method stub
		int arreglo[];
		int vecesRepetida = 0;
		int maxRepetidas = 0;
		int resultado = -1;
		arreglo = new int[pilaRPC.size()];
		int i = 0;
		while(!pilaRPC.isEmpty()){
			arreglo[i] = (int) pilaRPC.pop();
			i++;
		}
		
		/*
		 * Calcula Moda
		 */
		
		for(int j = 0; j < arreglo.length; j++){
			vecesRepetida = 0;
			for(int k = 0; k < arreglo.length; k++){
				if(arreglo[k] == arreglo[j]){
					vecesRepetida++;
				}
			}
			if(vecesRepetida > maxRepetidas){
				maxRepetidas = vecesRepetida;
				resultado = arreglo[j];
			}
		}
		
		pilaRPC.push(new Integer(resultado));
		
	}

	@Override
	protected void modulo() {
		// TODO Auto-generated method stub
		int num1, num2;
		int resultado = -1;
		num1 = (int) pilaRPC.pop();
		num2 = (int) pilaRPC.pop();
		resultado = num1 % num2;
		pilaRPC.push(new Integer(resultado));
		
	}

	@Override
	protected void exponencial() {
		// TODO Auto-generated method stub
		int num1, num2;
		int resultado = -1;
		num1 = (int) pilaRPC.pop();
		num2 = (int) pilaRPC.pop();
		resultado = (int) Math.pow(num1, num2);
		pilaRPC.push(new Integer(resultado));
	}

	@Override
	protected void maximo() {
		// TODO Auto-generated method stub
		int arreglo[];
		int resultado = -1;
		arreglo = new int[pilaRPC.size()];
		int i = 0;
		while(!pilaRPC.isEmpty()){
			arreglo[i] = (int) pilaRPC.pop();
			i++;
		}
		/*
		 * Calcula Maximo
		 */
		resultado = arreglo[0];
		
		for(int j = 0; j < arreglo.length; j++){
			if(resultado < arreglo[j]){
				resultado = arreglo[j];
			}
		}
		pilaRPC.push(new Integer(resultado));
	}

	@Override
	protected void minimo() {
		// TODO Auto-generated method stub
		int arreglo[];
		int resultado = -1;
		arreglo = new int[pilaRPC.size()];
		int i = 0;
		while(!pilaRPC.isEmpty()){
			arreglo[i] = (int) pilaRPC.pop();
			i++;
		}
		/*
		 * Calcula Maximo
		 */
		resultado = arreglo[0];
		
		for(int j = 0; j < arreglo.length; j++){
			if(resultado > arreglo[j]){
				resultado = arreglo[j];
			}
		}
		pilaRPC.push(new Integer(resultado));
		
	}

}
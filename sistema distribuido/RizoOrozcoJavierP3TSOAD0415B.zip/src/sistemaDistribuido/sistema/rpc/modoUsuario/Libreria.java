package sistemaDistribuido.sistema.rpc.modoUsuario;

import java.util.Stack;

import sistemaDistribuido.util.Escribano;


/**
 * 
 * Javier Rizo Orozco
 * Practica 3
 * 208091714
 *
 */

public abstract class Libreria{
	
	public Stack<Object> pilaRPC = new Stack<Object>();
	public final int TAMANIO_BYTES_ID_EMISOR = 4;
	public final int TAMANIO_BYTES_ID_RECEPTOR = 4;
	public final int TAMANIO_BYTES_CODIGO_OPERACION = 2;
	public final int TAMANIO_BYTES_MENSAJE = 1014;
	public final int TAMANIO_BYTES_RESPUESTA = 1024;
	public final int INICIO_MENSAJE_RESPUESTA = 8;
	
	private Escribano esc;

	/**
	 * 
	 */
	public Libreria(Escribano esc){
		this.esc=esc;
	}

	/**
	 * 
	 */
	protected void imprime(String s){
		esc.imprime(s);
	}

	/**
	 * 
	 */
	protected void imprimeln(String s){
		esc.imprimeln(s);
	}

	/**
	 * Ejemplo para el paso intermedio de parametros en pila.
	 * Esto es lo que esta disponible como interfaz al usuario programador
	 */
	/*public int suma(int sum1,int sum2){
    //...
    suma();
    //...
    return 0;
  }*/


	public int suma(int sum1, int sum2){
		pilaRPC.push(new Integer(sum1));
		pilaRPC.push(new Integer(sum2));
		suma();
		return (int) pilaRPC.pop();
	}

	public int resta(int minuendo, int sustraendo){
		pilaRPC.push(new Integer(minuendo));
		pilaRPC.push(new Integer(sustraendo));
		resta();
		return (int) pilaRPC.pop();
	}

	public int multiplicacion(int multiplicando, int multiplicador){
		pilaRPC.push(new Integer(multiplicando));
		pilaRPC.push(new Integer(multiplicador));
		multiplicacion();
		return (int) pilaRPC.pop();		
	}

	public int division(int dividendo, int divisor){
		pilaRPC.push(new Integer(dividendo));
		pilaRPC.push(new Integer(divisor));
		division();
		return (int) pilaRPC.pop();
	}
	
	public int promedio(int arreglo[]){
		int longitud = arreglo.length;
		while(longitud > 0){
			pilaRPC.push(new Integer(arreglo[longitud - 1]));
			longitud--;
		}
		promedio();
		return (int) pilaRPC.pop();
	}
	
	public int maximo(int arreglo[]){
		int longitud = arreglo.length;
		while(longitud > 0){
			pilaRPC.push(new Integer(arreglo[longitud - 1]));
			longitud--;
		}
		maximo();
		return (int) pilaRPC.pop();
	}
	
	public int minimo(int arreglo[]){
		int longitud = arreglo.length;
		while(longitud > 0){
			pilaRPC.push(new Integer(arreglo[longitud - 1]));
			longitud--;
		}
		minimo();
		return (int) pilaRPC.pop();
	}
	
	
	public int moda(int arreglo[]){
		int longitud = arreglo.length;
		while(longitud > 0){
			pilaRPC.push(new Integer(arreglo[longitud - 1]));
			longitud--;
		}
		moda();
		return (int) pilaRPC.pop();
	}
	
	public int modulo(int mod1, int mod2){
		pilaRPC.push(new Integer(mod1));
		pilaRPC.push(new Integer(mod2));
		modulo();
		return (int) pilaRPC.pop();		
	}
	
	public int exponencial(int base, int exponente){
		pilaRPC.push(new Integer(base));
		pilaRPC.push(new Integer(exponente));
		exponencial();
		return (int) pilaRPC.pop();		
	}

	/**
	 * Servidor suma verdadera generable por un compilador estandar
	 * o resguardo de la misma por un compilador de resguardos.
	 */
	protected abstract void suma();
	protected abstract void resta();
	protected abstract void multiplicacion();
	protected abstract void division();
	protected abstract void promedio();
	protected abstract void moda();
	protected abstract void modulo();
	protected abstract void exponencial();
	protected abstract void maximo();
	protected abstract void minimo();
}
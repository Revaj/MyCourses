package sistemaDistribuido.sistema.rpc.modoUsuario;

//import sistemaDistribuido.sistema.rpc.modoMonitor.RPC;   //para pr�ctica 4
import java.util.StringTokenizer;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.CadenaBytes;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;
import sistemaDistribuido.util.Pausador;


/**
 * 
 * Javier Rizo Orozco
 * Practica 3
 * 208091714
 *
 */
public class ProcesoServidor extends Proceso{
	private LibreriaServidor ls;   //para pr�ctica 3
	public final int TAMANIO_BYTES_ID_EMISOR = 4;
	public final int TAMANIO_BYTES_ID_RECEPTOR = 4;
	public final int TAMANIO_BYTES_CODIGO_OPERACION = 2;
	public final int TAMANIO_BYTES_MENSAJE = 1016;
	public final int TAMANIO_BYTES_RESPUESTA = 1024;
	public final int CASO_SUMA = 0;
	public final int CASO_RESTA = 1;
	public final int CASO_MULTIPLICACION = 2;
	public final int CASO_DIVISION = 3;
	public final int CASO_PROMEDIO = 4;
	public final int CASO_MODA = 5;
	public final int CASO_EXPONENCIAL = 6;
	public final int CASO_MODULO = 7;
	public final int CASO_MAXIMO = 8;
	public final int CASO_MINIMO = 9;

	/**
	 * 
	 */
	public ProcesoServidor(Escribano esc){
		super(esc);
		ls=new LibreriaServidor(esc);   //para pr�ctica 3
		start();
	}

	/**
	 * Resguardo del servidor
	 */
	public void run(){
		imprimeln("Proceso servidor en ejecucion.");
		//idUnico=RPC.exportarInterfaz("FileServer", "3.1", asa)  //para pr�ctica 4
		byte[] solServidor=new byte[TAMANIO_BYTES_RESPUESTA];
		short codigoOperacion;
		StringTokenizer separador = null;
		byte[] respServidor;
		CadenaBytes conversor = new CadenaBytes();
		String mensaje = null;
		int resultado;
		int num1, num2;
		int [] arregloNumeros;
		int idCliente = -1;
		
		while(continuar()){
			Nucleo.receive(dameID(), solServidor);
			
			byte[] codop = new byte[TAMANIO_BYTES_CODIGO_OPERACION];
			codop[0] = solServidor[TAMANIO_BYTES_ID_EMISOR 
			                           + TAMANIO_BYTES_ID_RECEPTOR];
			codop[1] = solServidor[TAMANIO_BYTES_ID_EMISOR 
				                       + TAMANIO_BYTES_ID_RECEPTOR + 1];
			codigoOperacion = conversor.recuperaBytesShort(codop);
			byte [] mensajeBytes = new byte[TAMANIO_BYTES_MENSAJE];
			int longitudMensaje = (int) solServidor[10];
			longitudMensaje += TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR +
							   TAMANIO_BYTES_CODIGO_OPERACION + 1;
			
			for(int i = 10, j = 0; i < longitudMensaje; i++, j++){
				mensajeBytes[j] = solServidor[i];
			}
			
			mensaje = conversor.recuperaCadena(mensajeBytes);
			switch(codigoOperacion){
				case CASO_SUMA: //Suma
					imprimeln("Procesando Operacion Suma");
					imprimeln(mensaje);
					separador = new StringTokenizer(mensaje, ",");
					num1 = Integer.parseInt(separador.nextToken());
					num2 = Integer.parseInt(separador.nextToken());
					resultado = ls.suma(num1, num2);
					imprimeln("Resultado >> " + resultado);
				break;
				case CASO_RESTA: //Resta
					imprimeln("Procesando Operacion Resta");
					separador = new StringTokenizer(mensaje, ",");
					num1 = Integer.parseInt(separador.nextToken());
					num2 = Integer.parseInt(separador.nextToken());
					resultado = ls.resta(num1, num2);
					imprimeln("Resultado >> " + resultado);
				break;
				case CASO_MULTIPLICACION: //Multiplicacion
					imprimeln("Procesando Operacion Multiplicacion");
					separador = new StringTokenizer(mensaje, ",");
					num1 = Integer.parseInt(separador.nextToken());
					num2 = Integer.parseInt(separador.nextToken());
					resultado = ls.multiplicacion(num1, num2);
					imprimeln("Resultado >> " + resultado);
				break;
				case CASO_DIVISION: //Division
					imprimeln("Procesando Operacion Division");
					separador = new StringTokenizer(mensaje, ",");
					num1 = Integer.parseInt(separador.nextToken());
					num2 = Integer.parseInt(separador.nextToken());
					resultado = ls.division(num1, num2);
					imprimeln("Resultado >> " + resultado);
				break;
				case CASO_PROMEDIO: //Promedio
					imprimeln("Procesando Operacion Promedio");
					separador = new StringTokenizer(mensaje, ",");
					//Creamos el arreglo
					int cantPromedio = separador.countTokens();
					arregloNumeros = new int[cantPromedio];
					int cantP = 0;
					while(separador.hasMoreTokens()){
						arregloNumeros[cantP] = Integer.parseInt(separador.nextToken());
						cantP++;
					}
					resultado = ls.promedio(arregloNumeros);
					imprimeln("Resultado >> " + resultado);
				break;
				case CASO_MODA: //Moda
					imprimeln("Procesando Operacion Moda");
					separador = new StringTokenizer(mensaje, ",");
					//Creamos el arreglo
					int cantModa = separador.countTokens();
					arregloNumeros = new int[cantModa];
					int posModa = 0;
					while(separador.hasMoreTokens()){
						arregloNumeros[posModa] = Integer.parseInt(separador.nextToken());
						posModa++;
					}
					resultado = ls.moda(arregloNumeros);
					imprimeln("Resultado >> " + resultado);
				break;
				case CASO_MODULO: //Modulo
					imprimeln("Procesando Operacion Modulo");
					separador = new StringTokenizer(mensaje, ",");
					num1 = Integer.parseInt(separador.nextToken());
					num2 = Integer.parseInt(separador.nextToken());
					imprimeln(num1 + ":" + num2);
					resultado = ls.modulo(num1, num2);
					imprimeln("Resultado >> " + resultado);
				break;
				case CASO_EXPONENCIAL: //Exponencial
					imprimeln("Procesando Operacion Exponencial");
					separador = new StringTokenizer(mensaje, ",");
					num1 = Integer.parseInt(separador.nextToken());
					num2 = Integer.parseInt(separador.nextToken());
					resultado = ls.exponencial(num1, num2);
					imprimeln("Resultado >> " + resultado);
					break;
				case CASO_MAXIMO: //Maximo
					imprimeln("Procesando Operacion Maximo");
					separador = new StringTokenizer(mensaje, ",");
					//Creamos el arreglo
					int cantMax = separador.countTokens();
					arregloNumeros = new int[cantMax];
					int posMax = 0;
					while(separador.hasMoreTokens()){
						arregloNumeros[posMax] = Integer.parseInt(separador.nextToken());
						posMax++;
					}
					resultado = ls.maximo(arregloNumeros);
					imprimeln("Resultado >> " + resultado);
				break;
				
				case CASO_MINIMO: //Minimo
					imprimeln("Procesando Operacion Minimo");
					separador = new StringTokenizer(mensaje, ",");
					//Creamos el arreglo
					int cantMin = separador.countTokens();
					arregloNumeros = new int[cantMin];
					int posMin = 0;
					while(separador.hasMoreTokens()){
						arregloNumeros[posMin] = Integer.parseInt(separador.nextToken());
						posMin++;
					}
					resultado = ls.minimo(arregloNumeros);
					imprimeln("Resultado >> " + resultado);
				break;
				
				default:
					imprimeln("Operacion no Reconocida");
					resultado = 0xFFFFFFFF;
				break;
			}//Fin del Switch
			//Prepara mensaje
			idCliente = (int) solServidor[0];
			respServidor = new byte[TAMANIO_BYTES_RESPUESTA];
			mensajeBytes = new byte[TAMANIO_BYTES_MENSAJE];
			mensajeBytes = conversor.dameArregloBytes(Integer.toString(resultado));
			int limiteRespuesta = mensajeBytes.length + TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR;
			for(int i = 8, j = 0; i < limiteRespuesta; i++, j++) {
				respServidor[i] = mensajeBytes[j];
			}

			Pausador.pausa(1000);  //sin esta l�nea es posible que Servidor solicite send antes que Cliente solicite receive
			imprimeln("Enviando respuesta al cliente");
			Nucleo.send(idCliente, respServidor);
			
		}//Fin del while

		//RPC.deregistrarInterfaz(nombreServidor, version, idUnico)  //para pr�ctica 4
	}//Fin de run
}

package sistemaDistribuido.sistema.clienteServidor.modoMonitor;
/**
 * 
 * Javier Rizo Orozco
 * Practica 2
 * 208091714
 *
 */

public class MaquinaProceso {

    String ip;
    int id;

    public MaquinaProceso(String ip,int id){
        this.ip = ip;
        this.id = id;
    }
}
/**
 * Javier Agustin Rizo Orozco
 * Practica 1
 * 208091714
 * 
 */

package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;

/**
 * 
 */
public class ProcesoCliente extends Proceso{

	/**
	 * 
	 */
	private short codigoOperacion;
	private String mensaje;

	//Constantes a usar para tamanios
	private final int TAMANIO_BYTES_ID_EMISOR = 4;
	private final int TAMANIO_BYTES_ID_RECEPTOR = 4;
	private final int TAMANIO_BYTES_CODIGO_OPERACION = 2;
	private final int TAMANIO_BYTES_MENSAJE = 1014;
	private final int TAMANIO_BYTES_RESPUESTA = 1024;
	private final int INICIO_MENSAJE_RESPUESTA = 8;
	
	public ProcesoCliente(Escribano esc){
		super(esc);
		start();
	}
	
	public void setParametros(short codigoOperacion, String mensaje){
		this.codigoOperacion = codigoOperacion;
		this.mensaje = mensaje;
	}
	

	/**
	 * En tamanioMensaje agregamos + 1 porque el arreglo sera N+1 bytes, los N de longitud del caracter y uno para guardar la longitud original
	 */
	public void run(){
		imprimeln("Proceso cliente en ejecucion.");
		imprimeln("Esperando datos para continuar.");
		Nucleo.suspenderProceso();
		imprimeln("Hola =)");
		
		byte[] codigoOperacionBytes = new byte[TAMANIO_BYTES_CODIGO_OPERACION];
		byte[] mensajeBytes = new byte[TAMANIO_BYTES_MENSAJE];
		
		int tamanioMensaje = this.getMensaje().length() + 1;
		byte[] respuestaCliente = new byte[TAMANIO_BYTES_RESPUESTA];
		
		CadenaBytes conversor = new CadenaBytes();

		
		imprimeln("Generando mensaje a ser enviado");
		//Convertimos el codop y el mensaje a bytes
		codigoOperacionBytes = conversor.convierteByte(this.getCodigoOperacion());	
		mensajeBytes = conversor.dameArregloBytes(mensaje);
		
		int tamanioSolicitud =   TAMANIO_BYTES_ID_EMISOR 
							   + TAMANIO_BYTES_ID_RECEPTOR
				               + TAMANIO_BYTES_CODIGO_OPERACION
				               + tamanioMensaje;

		byte[] solicitudCliente = new byte[tamanioSolicitud];
		
		//Anade el CODOP  a la solicitud
		int inicioCodop = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR;
		for(int i = inicioCodop, j = 0; i < inicioCodop + TAMANIO_BYTES_CODIGO_OPERACION; 
			i++, j++){
			solicitudCliente[i] = codigoOperacionBytes[j];
		}
		
		
		//Aniade el mensaje a la solicitud
		int inicioMensaje = TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 
							TAMANIO_BYTES_CODIGO_OPERACION;
		
		for(int i = inicioMensaje, j = 0; i < tamanioSolicitud; i++, j++){
			solicitudCliente[i] = mensajeBytes[j];
		}
		
		imprimeln("Enviando mensaje");
		//Envia mensaje
		Nucleo.send(248,solicitudCliente);
		Nucleo.receive(dameID(),respuestaCliente);
		
		imprimeln("Procesando respuesta recibida por el servidor");
		//Desempaqueta
		String mensajeRespuesta;
		byte[] msjRespuestaBytes = new byte[TAMANIO_BYTES_RESPUESTA];
		if((int) respuestaCliente[INICIO_MENSAJE_RESPUESTA] > 0) {
			int limiteRespuesta = respuestaCliente[INICIO_MENSAJE_RESPUESTA];
			limiteRespuesta += TAMANIO_BYTES_ID_EMISOR + TAMANIO_BYTES_ID_RECEPTOR + 1;
			for(int i = INICIO_MENSAJE_RESPUESTA, j = 0; i < limiteRespuesta; i++, j++){
				msjRespuestaBytes[j] = respuestaCliente[i]; 
			}
			mensajeRespuesta = conversor.recuperaCadena(msjRespuestaBytes);	
			imprimeln("El Servidor me envio el siguiente Mensaje\n" + mensajeRespuesta);
		} else { //Por el momento un AU
			imprimeln("Recibo un AU, la direccion es desconocida :( ");
		}
	}

	public short getCodigoOperacion() {
		return codigoOperacion;
	}

	public void setCodigoOperacion(short codigoOperacion) {
		this.codigoOperacion = codigoOperacion;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}

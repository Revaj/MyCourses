package sistemaDistribuido.visual.rpc;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.rpc.modoUsuario.ProcesoCliente;
import sistemaDistribuido.visual.clienteServidor.ProcesoFrame;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Button;
import java.awt.Label;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * 
 * Javier Rizo Orozco
 * Practica 3
 * 208091714
 *
 */

public class ClienteFrame extends ProcesoFrame{
	private static final long serialVersionUID=1;
	private ProcesoCliente proc;
	private TextField campoElementosPromedio, campoSuma1, campoSuma2,
	campoResta1, campoResta2, campoMult1, campoMult2, campoDiv1, campoDiv2,
	campoBase, campoExp, campoElementosModa, campoMod1, campoMod2, campoMinimos,
	campoMaximos;
	private Button botonSolicitud;

	public ClienteFrame(RPCFrame frameNucleo){
		super(frameNucleo,"Cliente de Archivos");
		add("South",construirPanelSolicitud());
		validate();
		proc=new ProcesoCliente(this);
		fijarProceso(proc);
	}

	public Panel construirPanelSolicitud(){
		Panel pSolicitud,pcodop1,pcodop2,pcodop3,pcodop4, pcodop5, pcodop6,
		pcodop7, pcodop8, pcodop9, pcodop10, pboton;
		pSolicitud=new Panel();
		pcodop1=new Panel();
		pcodop2=new Panel();
		pcodop3=new Panel();
		pcodop4=new Panel();
		pcodop5 = new Panel();
		pcodop6 = new Panel();
		pcodop7 = new Panel();
		pcodop8 = new Panel();
		pcodop9 = new Panel();
		pcodop10 = new Panel();
		pboton=new Panel();
		campoElementosPromedio = new TextField(10);
		campoSuma1 = new TextField(10);
		campoSuma2 = new TextField(10);
		campoResta1 = new TextField(10);
		campoResta2 = new TextField(10);
		campoMult1 = new TextField(10);
		campoMult2 = new TextField(10);
		campoDiv1 = new TextField(10);
		campoDiv2 = new TextField(10);
		campoBase = new TextField(10);
		campoExp = new TextField(10);
		campoElementosModa = new TextField(10);
		campoMod1 = new TextField(10);
		campoMod2 = new TextField(10);
		campoMinimos = new TextField(10);
		campoMaximos = new TextField(10);
		pSolicitud.setLayout(new GridLayout(11,1));

		pcodop1.add(new Label("PROMEDIO >> "));
		pcodop1.add(new Label("Lista Num:"));
		pcodop1.add(campoElementosPromedio);
		
		pcodop2.add(new Label("Suma >> "));
		pcodop2.add(new Label("Numero1:"));
		pcodop2.add(campoSuma1);
		pcodop2.add(new Label("Numero2:"));
		pcodop2.add(campoSuma2);

		pcodop3.add(new Label("Resta >> "));
		pcodop3.add(new Label("Numero1:"));
		pcodop3.add(campoResta1);
		pcodop3.add(new Label("Numero2:"));
		pcodop3.add(campoResta2);

		pcodop4.add(new Label("Multiplicacion >> "));
		pcodop4.add(new Label("Numero1:"));
		pcodop4.add(campoMult1);
		pcodop4.add(new Label("Numero2:"));
		pcodop4.add(campoMult2);
		
		pcodop5.add(new Label("Division >> "));
		pcodop5.add(new Label("Numero1:"));
		pcodop5.add(campoDiv1);
		pcodop5.add(new Label("Numero2:"));
		pcodop5.add(campoDiv2);
		
		pcodop6.add(new Label("Exponencial >> "));
		pcodop6.add(new Label("Base:"));
		pcodop6.add(campoBase);
		pcodop6.add(new Label("Exponente:"));
		pcodop6.add(campoExp);
		
		pcodop7.add(new Label("Moda >> "));
		pcodop7.add(new Label("Lista Numeros:"));
		pcodop7.add(campoElementosModa);
		
		pcodop8.add(new Label("Modulo >> "));
		pcodop8.add(new Label("Numero1:"));
		pcodop8.add(campoMod1);
		pcodop8.add(new Label("Numero2:"));
		pcodop8.add(campoMod2);
		
		pcodop9.add(new Label("Minimo >> "));
		pcodop9.add(new Label("Lista Numeros:"));
		pcodop9.add(campoMinimos);
		
		pcodop10.add(new Label("Maximo >> "));
		pcodop10.add(new Label("Lista Numeros:"));
		pcodop10.add(campoMaximos);
		
		botonSolicitud=new Button("Solicitar");
		pboton.add(botonSolicitud);
		botonSolicitud.addActionListener(new ManejadorSolicitud());

		pSolicitud.add(pcodop1);
		pSolicitud.add(pcodop2);
		pSolicitud.add(pcodop3);
		pSolicitud.add(pcodop4);
		pSolicitud.add(pcodop5);
		pSolicitud.add(pcodop6);
		pSolicitud.add(pcodop7);
		pSolicitud.add(pcodop8);
		pSolicitud.add(pcodop9);
		pSolicitud.add(pcodop10);
		pSolicitud.add(pboton);

		return pSolicitud;
	}

	class ManejadorSolicitud implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			String com=e.getActionCommand();
			if (com.equals("Solicitar")){
				botonSolicitud.setEnabled(false);
				//...
				if(campoSuma1.getText().length() > 0 && campoSuma2.getText().length() > 0){ 
					proc.reciboSuma(Integer.parseInt(campoSuma1.getText()), 
							        Integer.parseInt(campoSuma2.getText()));
				}
				
				if(campoResta1.getText().length() > 0 && campoResta2.getText().length() > 0){ 
					proc.reciboResta(Integer.parseInt(campoResta1.getText()), 
							        Integer.parseInt(campoResta2.getText()));
				}
				
				if(campoMult1.getText().length() > 0 && campoMult2.getText().length() > 0){ 
					proc.reciboMultiplicacion(Integer.parseInt(campoMult1.getText()), 
							        Integer.parseInt(campoMult2.getText()));
				}
				
				if(campoDiv1.getText().length() > 0 && campoDiv2.getText().length() > 0){ 
					proc.reciboDivision(Integer.parseInt(campoDiv1.getText()), 
							        Integer.parseInt(campoDiv2.getText()));
				}
				
				if(campoElementosPromedio.getText().length() > 0){ 
					proc.reciboPromedio(campoElementosPromedio.getText());
				}
				
				if(campoElementosModa.getText().length() > 0){ 
					proc.reciboModa(campoElementosModa.getText());
				}
				
				if(campoBase.getText().length() > 0 && campoExp.getText().length() > 0){ 
					proc.reciboExponente(Integer.parseInt(campoBase.getText()), 
							        Integer.parseInt(campoExp.getText()));
				}
				
				if(campoMod1.getText().length() > 0 && campoMod2.getText().length() > 0){ 
					proc.reciboMod(Integer.parseInt(campoMod1.getText()), 
							        Integer.parseInt(campoMod2.getText()));
				}
				
				if(campoMinimos.getText().length() > 0){
					proc.reciboMinimos(campoMinimos.getText());
				}
				
				if(campoMaximos.getText().length() > 0){
					proc.reciboMaximos(campoMaximos.getText());
				}
				
				Nucleo.reanudarProceso(proc);
			}
		}
	}
}
